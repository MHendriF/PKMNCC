<?php $__env->startSection('title'); ?>
    Omah Sakti | Home
<?php $__env->stopSection(); ?>

<?php $__env->startPush('stylesheets'); ?>
        <!-- Animate -->
      <link href="<?php echo e(asset("assets/animate.css/animate.min.css")); ?>" rel="stylesheet" type="text/css"/>
      <!-- PNotify -->
      <link href="<?php echo e(asset("assets/pnotify/dist/pnotify.css")); ?>" rel="stylesheet">
      <link href="<?php echo e(asset("assets/pnotify/dist/pnotify.buttons.css")); ?>" rel="stylesheet">
      <link href="<?php echo e(asset("assets/pnotify/dist/pnotify.nonblock.css")); ?>" rel="stylesheet">
      <!-- Sweetalert -->
      <link href="<?php echo e(asset("css/sweetalert2/sweetalert2.min.css")); ?>" rel="stylesheet">
      <!-- Custom Theme Style -->
      <link href="<?php echo e(asset("build/css/action-icon.css")); ?>" rel="stylesheet"> 
      <link href="<?php echo e(asset("build/css/custom.min2.css")); ?>" rel="stylesheet">  
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main_container'); ?>

    <!-- page content -->
    <div class="right_col" role="main">
        <div class="">
      
            <section class="page-title">
                <div class="title_left">
                  <h3>Home Dasboard</h3>
                </div>
                <div class="title_right">
                  <div class="pull-right">
                    <section class="content-header">
                      <ol class="breadcrumb">
                      <li class="active"><a href="<?php echo e(url('general')); ?>"><i class="fa fa-home"></i>Home</a></li>
                    </ol>  
                    </section>
                  </div>
                </div>
          </section>

            <div class="x_content">
                <div class="row">
                    
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                          <div class="x_title">
                            <h2>Welcome</h2>
                            <ul class="nav navbar-right panel_toolbox">
                              <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                              <li><a href="<?php echo e(url('general')); ?>"><i class="fa fa-repeat"></i></a></li>
                              <li><a class="close-link"><i class="fa fa-close"></i></a></li>
                            </ul>
                            <div class="clearfix"></div>
                          </div>
                          <div class="x_content">

                            <p>Data Pengguna</p>
                            <p>Nama : <?php echo e(Auth::user()->name); ?></p>
                            <p>Email : <?php echo e(Auth::user()->email); ?></p>
                            <p>No Hp : <?php echo e(Auth::user()->no_hp); ?></p>
                            <p>Alamat : <?php echo e(Auth::user()->alamat); ?></p>
                            <p>Kota : <?php echo e(Auth::user()->kota_domisili); ?></p>
                            <p>Negara : <?php echo e(Auth::user()->negara_domisili); ?></p>
                            
                                
                          </div>
                        </div>
                      </div>

                </div>
            </div>

        </div>
    </div>
    <!-- /page content -->

    <!-- footer content -->
    <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /footer content -->

    <?php $__env->startPush('scripts'); ?>

        <!-- PNotify -->
        <script src="<?php echo e(asset("assets/pnotify/dist/pnotify.js")); ?>"></script>
        <script src="<?php echo e(asset("assets/pnotify/dist/pnotify.animate.js")); ?>"></script>
        <script src="<?php echo e(asset("assets/pnotify/dist/pnotify.buttons.js")); ?>"></script>
        <script src="<?php echo e(asset("assets/pnotify/dist/pnotify.nonblock.js")); ?>"></script>
        <!-- Sweetalert -->
        <script src="<?php echo e(asset("js/sweetalert2/sweetalert2.min.js")); ?>"></script>
        <!-- Custom Theme Scripts -->
        <script src="<?php echo e(asset("build/js/custom.min2.js")); ?>"></script>

        <!-- Include Scripts -->
        <?php echo $__env->make('javascript.pnotify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('javascript.sweetalert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.blank', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>