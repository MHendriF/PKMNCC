<?php $__env->startSection('title'); ?>
    PKM NCC | Set On/Off
<?php $__env->stopSection(); ?>

<?php $__env->startPush('stylesheets'); ?>
     <!-- iCheck -->
    <link href="<?php echo e(asset("assets/iCheck/skins/flat/green.css")); ?>" rel="stylesheet">
     <!-- iCheck -->
    <link href="<?php echo e(asset("assets/switchery/dist/switchery.min.css")); ?>" rel="stylesheet">
    <!-- Select2 -->
    <link href="<?php echo e(asset("assets/select2/dist/css/select2.min.css")); ?>" rel="stylesheet">
    <!-- Animate -->
    <link href="<?php echo e(asset("assets/animate.css/animate.min.css")); ?>" rel="stylesheet" type="text/css"/>
    <!-- PNotify -->
    <link href="<?php echo e(asset("assets/pnotify/dist/pnotify.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(asset("assets/pnotify/dist/pnotify.buttons.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(asset("assets/pnotify/dist/pnotify.nonblock.css")); ?>" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="<?php echo e(asset("build/css/action-icon.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(asset("build/css/custom.min2.css")); ?>" rel="stylesheet"> 
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main_container'); ?>
    <!-- page content -->
    <div class="right_col" role="main">
        <div class="">
            
            <section class="page-title">
                <div class="title_left">
                  <h3>Set On/Off</h3>
                </div>
                <div class="title_right">
                  <div class="pull-right">
                    <section class="content-header">
                      <ol class="breadcrumb">
                      <li><a href="<?php echo e(url('home')); ?>"><i class="fa fa-home"></i>Home</a></li>
                      <li class="active">Set On/Off</li>
                    </ol>  
                    </section>
                  </div>
                </div>
            </section>

        </div class="clearfix">

        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                      <h2>Set On/Off</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                            <li><a class="close-link"><i class="fa fa-close"></i></a></li>
                        </ul>
                      <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <br />
                        <form method="post" action="<?php echo e(url('on_off')); ?>" id="demo-form2" class="form-horizontal form-label-left">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label class="control-label col-md-5">Lampu 1 : 
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                  <div class="sensor">
                                    <label>Off</label>
                                    <label>
                                      <input type="checkbox" class="js-switch"  checked /> On
                                    </label>
                                  </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-5">Lampu 2 : 
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                  <div class="sensor">
                                    <label>Off</label>
                                    <label>
                                      <input type="checkbox" class="js-switch" checked /> On
                                    </label>
                                  </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-5">Lampu 3 : 
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                  <div class="sensor">
                                    <label>Off</label>
                                    <label>
                                      <input type="checkbox" class="js-switch" unchecked /> On
                                    </label>
                                  </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-5">Lampu 4 : 
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                  <div class="sensor">
                                    <label>Off</label>
                                    <label>
                                      <input type="checkbox" class="js-switch" checked /> On
                                    </label>
                                  </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-5">Lampu 5 : 
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                  <div class="sensor">
                                    <label>Off</label>
                                    <label>
                                      <input type="checkbox" class="js-switch" unchecked /> On
                                    </label>
                                  </div>
                                </div>
                            </div>

                            
                        </form>

            
                        <!-- Modal -->
                          <div class="modal fade" id="showModal" role="dialog">
                            <div class="modal-dialog">
                            
                              <!-- Modal content-->
                              <div class="modal-content">
                                <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                  <h4 class="modal-title">Modal Header</h4>
                                </div>
                                <div class="modal-body">
                                  <p>Some text in the modal.</p>
                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                </div>
                              </div>
                              
                            </div>
                          </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /page content -->

    <!-- footer content -->
    <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /footer content -->

    <?php $__env->startPush('scripts'); ?>

    <!-- iCheck -->
    <script src="<?php echo e(asset("assets/iCheck/icheck.min.js")); ?>"></script>
    <!-- Switchery -->
    <script src="<?php echo e(asset("assets/switchery/dist/switchery.min.js")); ?>"></script>
    <!-- Select2 -->
    <script src="<?php echo e(asset("assets/select2/dist/js/select2.full.min.js")); ?>"></script>
    
    <!-- PNotify -->
    <script src="<?php echo e(asset("assets/pnotify/dist/pnotify.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/pnotify/dist/pnotify.animate.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/pnotify/dist/pnotify.buttons.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/pnotify/dist/pnotify.nonblock.js")); ?>"></script>
    <!-- Custom Theme Scripts -->
    <script src="<?php echo e(asset("build/js/custom.min2.js")); ?>"></script>
    <!-- Include Scripts -->
    <?php echo $__env->make('javascript.pnotify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    

    

    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blank', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>