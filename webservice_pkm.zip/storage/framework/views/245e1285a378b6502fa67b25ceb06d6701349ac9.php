            <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
                    <li>
                        <a href="<?php echo e(url('home')); ?>">
                            <i class="fa fa-home"></i>Home
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('#')); ?>">
                            <i class="fa fa-bar-chart"></i>Data Sensor
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('on_off')); ?>">
                            <i class="fa fa-power-off"></i>Set On/Off
                        </a>
                    </li>
                </ul>
            </div>