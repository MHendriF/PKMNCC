            <div class="menu_section">
                <a href="<?php echo e(url('general')); ?>" ><h3>General</h3></a>
                <ul class="nav side-menu">
                    <li><a><i class="fa fa-home"></i> General Menu <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="<?php echo e(url('home')); ?>">Home</a></li>
                            <li><a href="<?php echo e(url('inventory')); ?>">Inventory</a></li>
                            <li><a href="<?php echo e(url('location')); ?>">Location</a></li>
                            <li><a href="<?php echo e(url('shipping')); ?>">Shipping</a></li>
                            <li><a href="<?php echo e(url('customer')); ?>">Customers</a></li>
                            <li><a href="<?php echo e(url('technician')); ?>">Technician</a></li>
                            <li><a href="<?php echo e(url('category')); ?>">Category</a></li>
                            
                            
                        </ul>
                    </li>
                </ul>
            </div>
            <div class="menu_section">
                <a href="<?php echo e(url('master')); ?>" ><h3>Master</h3></a>
                <ul class="nav side-menu">
                    <li><a><i class="fa fa-user-md"></i> Master Menu <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="<?php echo e(url('purchase/create')); ?>">Purchase</a></li>
                            <li><a href="<?php echo e(url('order/create')); ?>">Order</a></li>
                            <li><a href="<?php echo e(url('location/create')); ?>">Add Location</a></li>
                            <li><a href="<?php echo e(url('inventory/create')); ?>">Add Inventory</a></li>
                            <li><a href="<?php echo e(url('category/create')); ?>">Add Category</a></li>
                            <li><a href="<?php echo e(url('customer/create')); ?>">Add Customers</a></li>
                            <li><a href="<?php echo e(url('supplier/create')); ?>">Add Suppliers</a></li>
                            <li><a href="<?php echo e(url('user/create')); ?>">Add Employee</a></li>
                            <li><a href="<?php echo e(url('service/create')); ?>">Add Service</a></li>
                            <li><a href="<?php echo e(url('transaction/create')); ?>">Transaction</a></li>

                        </ul>
                    </li>
                </ul>
            </div>
            <div class="menu_section">
                <a href="<?php echo e(url('report')); ?>" ><h3>Report</h3></a>
                <ul class="nav side-menu">
                    <li>
                        <a><i class="fa fa-table"></i> Report Menu <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="<?php echo e(url('inventory')); ?>">Report Inventory</a></li>
                            <li><a href="<?php echo e(url('purchase')); ?>">Report Purchase</a></li>
                            <li><a href="<?php echo e(url('order')); ?>">Report Order</a></li>
                            <li><a href="<?php echo e(url('service')); ?>">Report Service</a></li>
                            <li><a href="<?php echo e(url('transaction')); ?>">Report Transaction</a></li>
                            <li><a href="<?php echo e(url('finance')); ?>">Report Keuangan Bulanan</a></li>
                            <li><a href="<?php echo e(url('')); ?>">Report Biaya Teknisi</a></li>
                        </ul>
                    </li>
                </ul>
            </div>