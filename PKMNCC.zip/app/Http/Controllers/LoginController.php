<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LoginController extends Controller
{
    public function login()
    {
    	return view('auth.login');
    }

    public function postLogin(Request $request)
    {
    	return redirect('/');
    }
}
