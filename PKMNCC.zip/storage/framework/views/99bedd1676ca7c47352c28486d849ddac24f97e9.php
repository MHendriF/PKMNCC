                                <div class="animated homewidget col-md-2">
                                    <a href="<?php echo e(url('home')); ?>" class="bttn btn-default bttn-lg">
                                        <i class="fa fa-home" style="margin-right: 7px;"></i>Home
                                    </a>
                                </div>
                                 <div class="animated homewidget col-md-2">
                                    <a href="<?php echo e(url('salary')); ?>" class="bttn btn-default bttn-lg">
                                        <i class="fa fa-money" style="margin-right: 7px;"></i>Data Sensor
                                    </a>
                                </div>
                                 <div class="animated homewidget col-md-2">
                                    <a href="<?php echo e(url('expense')); ?>" class="bttn btn-default bttn-lg">
                                        <i class="fa fa-power-off" style="margin-right: 7px;"></i>On/Off
                                    </a>
                                </div>
                                 <div class="animated homewidget col-md-2">
                                    <a href="<?php echo e(url('income')); ?>" class="bttn btn-default bttn-lg">
                                        <i class="fa fa-usd" style="margin-right: 7px;"></i>Biaya asli
                                    </a>
                                </div>
                                 <div class="animated homewidget col-md-2">
                                    <a href="<?php echo e(url('')); ?>" class="bttn btn-default bttn-lg">
                                        <i class="fa fa-usd" style="margin-right: 7px;"></i> Penghematan
                                    </a>
                                </div>
                                 <div class="animated homewidget col-md-2">
                                    <a href="<?php echo e(url('user')); ?>" class="bttn btn-default bttn-lg">
                                        <i class="fa fa-users" style="margin-right: 7px;"></i>Account
                                    </a>
                                </div>
                                 