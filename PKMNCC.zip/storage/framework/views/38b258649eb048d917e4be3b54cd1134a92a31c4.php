<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

        <!-- Meta, title, CSS, favicons, etc. -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo $__env->yieldContent('title'); ?></title>

        <!-- Bootstrap -->
        <link href="<?php echo e(asset("assets/bootstrap/dist/css/bootstrap.min.css")); ?>" rel="stylesheet">
        <!-- Font Awesome -->
        <link href="<?php echo e(asset("assets/font-awesome-4.7.0/css/font-awesome.min.css")); ?>" rel="stylesheet">
        <!-- NProgress -->
        <link href="<?php echo e(asset("assets/nprogress/nprogress.css")); ?>" rel="stylesheet">
    
        <?php echo $__env->yieldPushContent('stylesheets'); ?>
    </head>

    <body class="nav-md">
        <div class="container body">
            <div class="main_container">

                <?php echo $__env->make('includes/sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <?php echo $__env->make('includes/topbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <?php echo $__env->yieldContent('main_container'); ?>

            </div>
        </div>
        
        <!-- jQuery -->
        <script src="<?php echo e(asset("assets/jquery/dist/jquery.min.js")); ?>"></script>
        <!-- Bootstrap -->
        <script src="<?php echo e(asset("assets/bootstrap/dist/js/bootstrap.min.js")); ?>"></script>
        <!-- FastClick -->
        <script src="<?php echo e(asset("assets/fastclick/lib/fastclick.js")); ?>"></script>
        <!-- NProgress -->
        <script src="<?php echo e(asset("assets/nprogress/nprogress.js")); ?>"></script>
        
        <?php echo $__env->yieldPushContent('scripts'); ?>

    </body>
</html>