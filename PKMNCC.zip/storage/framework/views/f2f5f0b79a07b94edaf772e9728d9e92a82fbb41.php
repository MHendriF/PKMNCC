<?php $__env->startSection('title'); ?>
    PKM NCC | Record Device
<?php $__env->stopSection(); ?>

<?php $__env->startPush('stylesheets'); ?>
   
    <!-- Datatables -->
    <link href="<?php echo e(asset("assets/datatables.net-bs/css/dataTables.bootstrap.min.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(asset("assets/datatables.net-responsive-bs/css/responsive.bootstrap.min.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(asset("assets/datatables.net-scroller-bs/css/scroller.bootstrap.min.css")); ?>" rel="stylesheet">
    <!-- Animate -->
    <link href="<?php echo e(asset("assets/animate.css/animate.min.css")); ?>" rel="stylesheet" type="text/css"/>
    <!-- PNotify -->
    <link href="<?php echo e(asset("assets/pnotify/dist/pnotify.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(asset("assets/pnotify/dist/pnotify.buttons.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(asset("assets/pnotify/dist/pnotify.nonblock.css")); ?>" rel="stylesheet">
    <!-- Sweetalert2 -->
    <link href="<?php echo e(asset("assets/sweetalert2/dist/sweetalert2.min.css")); ?>" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="<?php echo e(asset("build/css/action-icon.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(asset("build/css/custom.min2.css")); ?>" rel="stylesheet"> 
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main_container'); ?>
    <!-- page content -->
    <div class="right_col" role="main">
        <div class="">
            
            <section class="page-title">
                <div class="title_left">
                  <h3>Record Device</h3>
                </div>
                <div class="title_right">
                  <div class="pull-right">
                    <section class="content-header">
                      <ol class="breadcrumb">
                      <li><a href="<?php echo e(url('home')); ?>"><i class="fa fa-home"></i>Home</a></li>
                      <li class="active">Record Device</li>
                    </ol>  
                    </section>
                  </div>
                </div>
            </section>

        </div class="clearfix">

        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Device<small>
                      <a href="<?php echo e(url('device/create')); ?>" class="btn btn-primary btn-xs">
                        <i class="fa fa-plus-square" style="margin-right: 6px;"></i>Tambah Device
                      </a>
                      </small>
                    </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                      <li><a href="<?php echo e(url('device')); ?>"><i class="fa fa-repeat"></i></a></li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a></li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Nama</th>
                          <th>Status</th>
                          <th>Deskripsi</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <tr>
                            <td><?php echo e($index +1); ?></td>
                            <td><?php echo e($item->nama_device); ?></td>
                            <td><?php echo e($item->status_device); ?></td>
                            <td><?php echo e($item->deskripsi); ?></td>
                            <td>
                              <center>
                                <div class="btn-group">
                                  <a href="<?php echo e(url('device/'.$item->id.'/edit')); ?>" class="btn btn-success btn-xs" class="tooltip-top" title="" data-tooltip="Edit"><i class="fa fa-pencil"></i></a>
                                </div>
                                <div class="btn-group">
                                  <form action="<?php echo e(url('device/'.$item->id)); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="_method" value="DELETE">
                                    <button id="delete" type="submit" class="btn btn-danger btn-xs" class="tooltip-top" title="" data-tooltip="Delete"><i class="fa fa-trash"></i></button>
                                  </form>
                                </div>
                              </center>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

        </div>
    </div>
    <!-- /page content -->

    <!-- footer content -->
    <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /footer content -->

    <?php $__env->startPush('scripts'); ?>

    <!-- Datatables -->
    <script src="<?php echo e(asset("assets/datatables.net/js/jquery.dataTables.min.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/datatables.net-bs/js/dataTables.bootstrap.min.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/datatables.net-responsive/js/dataTables.responsive.min.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/datatables.net-responsive-bs/js/responsive.bootstrap.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/datatables.net-scroller/js/datatables.scroller.min.js")); ?>"></script>
    <!-- Sweetalert2 -->
    <script src="<?php echo e(asset("assets/sweetalert2/dist/sweetalert2.min.js")); ?>"></script>
    <!-- PNotify -->
    <script src="<?php echo e(asset("assets/pnotify/dist/pnotify.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/pnotify/dist/pnotify.animate.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/pnotify/dist/pnotify.buttons.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/pnotify/dist/pnotify.nonblock.js")); ?>"></script>
    <!-- Custom Theme Scripts -->
    <script src="<?php echo e(asset("build/js/custom.min2.js")); ?>"></script>
    <!-- Include Scripts -->

    <?php echo $__env->make('javascript.datatables', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('javascript.pnotify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blank', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>