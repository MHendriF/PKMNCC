 <!-- PNotify -->
    <script>
      $(document).ready(function() {
          <?php if(Session::has('new')): ?>
            new PNotify({
              title: "Create",
              type: "success",
              text: "<?php echo e(Session::get('new')); ?>",
              delay: "2500",
              // nonblock: {
              //     nonblock: true,
              //     nonblock_opacity: .2
              // },
              animate: {
                animate: true,
                in_class: 'bounceIn',
                out_class: 'bounceOut'
              },
              styling: 'bootstrap3',
              hide: true,
            });
          <?php elseif(Session::has('update')): ?>
            new PNotify({
              title: "Update",
              type: "success",
              text: "<?php echo e(Session::get('update')); ?>",
              delay: "2500",
              // nonblock: {
              //     nonblock: true,
              //     nonblock_opacity: .2
              // },
              animate: {
                animate: true,
                in_class: 'bounceIn',
                out_class: 'bounceOut'
              },
              styling: 'bootstrap3',
              hide: true,
              shadow: true,
            });
          <?php elseif(Session::has('delete')): ?>
            new PNotify({
              title: "Delete",
              type: "success",
              text: "<?php echo e(Session::get('delete')); ?>",
              delay: "2500",
              // nonblock: {
              //     nonblock: true,
              //     nonblock_opacity: .2
              // },
              animate: {
                animate: true,
                in_class: 'bounceIn',
                out_class: 'bounceOut'
              },
              styling: 'bootstrap3',
              hide: true,
              shadow: true,
            });
          <?php elseif(Session::has('error')): ?>
            new PNotify({
              title: "Error",
              type: "error",
              text: "<?php echo e(Session::get('error')); ?>",
              delay: "3000",
              // nonblock: {
              //     nonblock: true,
              //     nonblock_opacity: .2
              // },
              animate: {
                animate: true,
                in_class: 'bounceIn',
                out_class: 'bounceOut'
              },
              styling: 'bootstrap3',
              hide: true,
              shadow: true,
            });
          <?php endif; ?>
        });
    </script>
    <!-- /PNotify -->