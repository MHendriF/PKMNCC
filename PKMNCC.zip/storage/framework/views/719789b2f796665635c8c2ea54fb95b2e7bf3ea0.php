	<footer>
		<div class="pull-right">
	    	PKM NCC - Copyright &copy; <?php echo e(date('Y')); ?> by <a href="https://colorlib.com">MHF</a>
	    </div>
	    <div class="clearfix"></div>
	</footer>